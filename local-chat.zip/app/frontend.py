"""
frontend.py - Serves the SPA at GET /
Flask app handles static/ and templates/ from project root.
"""
from flask import Blueprint, render_template

frontend_bp = Blueprint("frontend", __name__)


@frontend_bp.route("/", methods=["GET"])
def index():
    return render_template("index.html")


@frontend_bp.route("/api-keys", methods=["GET"])
def api_keys_page():
    return render_template("api-keys.html")
